[![code style: prettier](https://img.shields.io/badge/code_style-prettier-ff69b4.svg?style=flat-square)](https://github.com/prettier/prettier)
# VIDEOGRAPHY
#### Video Demo: URL [here](https://youtu.be/rsmm31qCk8w).
## Description:
Final project for [CS50x](https://cs50.harvard.edu/x/2022/).